# AOD Poco

Aplikasi Always-on Display untuk Poco C85 (layar LCD, jadi layar tetap menyala dengan kecerahan rendah).

- Area atas: template pilihanmu (gambar, GIF, atau video dari galeri)
- Bawah: jam, tanggal, baterai
- Ketuk 2x untuk keluar, ketuk 1x untuk memutar ulang animasi

## Build tanpa PC

1. Buat repository baru di GitHub, upload semua isi folder ini (termasuk folder `.github`).
2. Buka tab Actions, tunggu workflow "Build APK" selesai (atau jalankan manual lewat Run workflow).
3. Buka hasil run, unduh artifact `AOD-Poco-apk`, ekstrak, lalu install `app-debug.apk`.

## Setelan penting di HyperOS

- Izin "Tampil di atas aplikasi lain"
- Autostart: aktif
- Baterai: tanpa batasan
- Izin "Tampilkan pop-up saat berjalan di latar belakang": aktif
