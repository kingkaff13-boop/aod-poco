package com.kirnai.aod;

import android.content.Context;
import android.graphics.ImageDecoder;
import android.graphics.drawable.Drawable;
import android.net.Uri;

/** Menyimpan template gambar/GIF yang sudah di-decode supaya AOD langsung tampil tanpa menunggu. */
final class TemplateCache {
    private static String key;
    private static Drawable drawable;

    private TemplateCache() {}

    private static Drawable decode(Context c, Uri u) throws Exception {
        return ImageDecoder.decodeDrawable(
                ImageDecoder.createSource(c.getContentResolver(), u),
                (decoder, info, src) -> {
                    int big = Math.max(info.getSize().getWidth(), info.getSize().getHeight());
                    decoder.setTargetSampleSize(Math.max(1, big / 1600));
                });
    }

    /** Ambil dari cache; kalau belum ada, decode sekarang lalu simpan. */
    static synchronized Drawable get(Context c, Uri u) throws Exception {
        String k = u.toString();
        if (drawable != null && k.equals(key)) return drawable;
        Drawable d = decode(c, u);
        key = k;
        drawable = d;
        return d;
    }

    /** Siapkan template di latar belakang (dipanggil saat layanan mulai dan saat template diganti). */
    static void warm(Context c) {
        final Context app = c.getApplicationContext();
        final String us = Prefs.get(app).getString(Prefs.TEMPLATE_URI, null);
        final String mime = Prefs.get(app).getString(Prefs.TEMPLATE_MIME, "");
        if (us == null || (mime != null && mime.startsWith("video"))) return;
        new Thread(() -> {
            try {
                get(app, Uri.parse(us));
            } catch (Exception ignored) {
            }
        }).start();
    }
}
