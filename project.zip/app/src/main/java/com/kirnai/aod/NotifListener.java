package com.kirnai.aod;

import android.app.Notification;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Menghitung pesan belum dibaca dari notifikasi yang sedang tampil (butuh izin Akses Notifikasi). */
public class NotifListener extends NotificationListenerService {
    static volatile int wa;
    static volatile int other;
    static volatile Runnable onChange;

    private static final Set<String> OTHER = new HashSet<>(Arrays.asList(
            "org.telegram.messenger", "com.facebook.orca", "com.facebook.mlite", "com.instagram.android",
            "com.google.android.apps.messaging", "com.android.mms", "jp.naver.line.android",
            "org.thoughtcrime.securesms", "com.discord", "com.samsung.android.messaging"));

    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    public void onListenerConnected() {
        recount();
    }

    @Override
    public void onListenerDisconnected() {
        wa = 0;
        other = 0;
        notifyChange();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        recount();
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        recount();
    }

    private void notifyChange() {
        final Runnable r = onChange;
        if (r != null) main.post(r);
    }

    private void recount() {
        int w = 0;
        int o = 0;
        try {
            StatusBarNotification[] all = getActiveNotifications();
            if (all != null) {
                for (StatusBarNotification s : all) {
                    String pkg = s.getPackageName();
                    if (pkg.equals(getPackageName())) continue;
                    Notification n = s.getNotification();
                    if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) continue;
                    if ((n.flags & Notification.FLAG_ONGOING_EVENT) != 0) continue;

                    boolean isWa = pkg.equals("com.whatsapp") || pkg.equals("com.whatsapp.w4b");
                    Bundle ex = n.extras;
                    Parcelable[] ms = ex == null ? null : ex.getParcelableArray(Notification.EXTRA_MESSAGES);
                    boolean isMsgCat = Notification.CATEGORY_MESSAGE.equals(n.category);

                    if (isWa) {
                        if (!isMsgCat && ms == null) continue;
                    } else if (!(isMsgCat || OTHER.contains(pkg))) {
                        continue;
                    }

                    int cnt = 1;
                    if (ms != null && ms.length > 0) cnt = ms.length;
                    else if (n.number > 0) cnt = n.number;

                    if (isWa) w += cnt;
                    else o += cnt;
                }
            }
        } catch (Exception e) {
            return;
        }
        wa = w;
        other = o;
        notifyChange();
    }
}
