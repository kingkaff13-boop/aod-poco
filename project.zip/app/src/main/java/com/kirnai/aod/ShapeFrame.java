package com.kirnai.aod;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Path;
import android.graphics.RectF;
import android.widget.FrameLayout;

/** Wadah template yang bisa dipotong jadi bentuk: bulat, kotak, segi enam, dll. */
public class ShapeFrame extends FrameLayout {
    static final String[] KEYS = {"asli", "bulat", "kotak", "tumpul", "hex", "oktagon", "belah", "segitiga", "bintang", "hati"};
    static final String[] LABELS = {"Asli (tanpa potongan)", "Bulat", "Kotak", "Kotak tumpul", "Segi enam",
            "Segi delapan", "Belah ketupat", "Segitiga", "Bintang", "Hati"};

    private final Path path = new Path();
    private String shape = "asli";

    public ShapeFrame(Context c) {
        super(c);
    }

    void setShape(String s) {
        shape = s == null ? "asli" : s;
        rebuild();
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        rebuild();
    }

    private void poly(float cx, float cy, float r, int n, float startDeg) {
        for (int i = 0; i < n; i++) {
            double a = Math.toRadians(startDeg + 360.0 * i / n);
            float x = (float) (cx + r * Math.cos(a));
            float y = (float) (cy + r * Math.sin(a));
            if (i == 0) path.moveTo(x, y);
            else path.lineTo(x, y);
        }
        path.close();
    }

    private void rebuild() {
        path.reset();
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) / 2f;
        switch (shape) {
            case "bulat":
                path.addCircle(cx, cy, r, Path.Direction.CW);
                break;
            case "kotak":
                path.addRect(0, 0, w, h, Path.Direction.CW);
                break;
            case "tumpul":
                path.addRoundRect(new RectF(0, 0, w, h), w * 0.24f, h * 0.24f, Path.Direction.CW);
                break;
            case "hex":
                poly(cx, cy, r, 6, -90);
                break;
            case "oktagon":
                poly(cx, cy, r, 8, -67.5f);
                break;
            case "belah":
                poly(cx, cy, r, 4, -90);
                break;
            case "segitiga":
                poly(cx, cy + r * 0.25f, r, 3, -90);
                break;
            case "bintang":
                for (int i = 0; i < 10; i++) {
                    double a = Math.toRadians(-90 + 36.0 * i);
                    float rr = (i % 2 == 0) ? r : r * 0.45f;
                    float x = (float) (cx + rr * Math.cos(a));
                    float y = (float) (cy + rr * Math.sin(a));
                    if (i == 0) path.moveTo(x, y);
                    else path.lineTo(x, y);
                }
                path.close();
                break;
            case "hati":
                path.moveTo(w * 0.5f, h * 0.92f);
                path.cubicTo(w * 0.02f, h * 0.62f, w * 0.0f, h * 0.28f, w * 0.25f, h * 0.14f);
                path.cubicTo(w * 0.38f, h * 0.07f, w * 0.48f, h * 0.15f, w * 0.5f, h * 0.28f);
                path.cubicTo(w * 0.52f, h * 0.15f, w * 0.62f, h * 0.07f, w * 0.75f, h * 0.14f);
                path.cubicTo(w * 1.0f, h * 0.28f, w * 0.98f, h * 0.62f, w * 0.5f, h * 0.92f);
                path.close();
                break;
            default:
                break;
        }
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        if (!"asli".equals(shape) && !path.isEmpty()) {
            int save = canvas.save();
            canvas.clipPath(path);
            super.dispatchDraw(canvas);
            canvas.restoreToCount(save);
        } else {
            super.dispatchDraw(canvas);
        }
    }
}
