package com.kirnai.aod;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Ikon baterai yang digambar sendiri (isi sesuai persen, petir saat mengisi). */
public class BatteryView extends View {
    private final float hh;
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bolt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint boltEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path bp = new Path();
    private int pct = 50;
    private boolean charging;
    private boolean showPct = true;

    public BatteryView(Context c, float heightPx) {
        super(c);
        hh = heightPx;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(hh * 0.09f);
        line.setColor(0xFFB0B0B0);
        fill.setStyle(Paint.Style.FILL);
        txt.setColor(0xFFCCCCCC);
        txt.setTextSize(hh * 0.95f);
        bolt.setStyle(Paint.Style.FILL);
        bolt.setColor(0xFFFFFFFF);
        boltEdge.setStyle(Paint.Style.STROKE);
        boltEdge.setStrokeWidth(hh * 0.05f);
        boltEdge.setColor(0xFF000000);
        boltEdge.setStrokeJoin(Paint.Join.ROUND);
    }

    void set(int pct, boolean charging, boolean showPct) {
        this.pct = Math.max(0, Math.min(100, pct));
        this.charging = charging;
        this.showPct = showPct;
        requestLayout();
        invalidate();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        float tw = showPct ? hh * 0.3f + txt.measureText(pct + "%") : 0f;
        setMeasuredDimension((int) Math.ceil(hh * 2f + hh * 0.14f + tw), (int) Math.ceil(hh));
    }

    @Override
    protected void onDraw(Canvas c) {
        float sw = line.getStrokeWidth();
        float bw = hh * 2f;

        r.set(sw / 2f, sw / 2f, bw - sw / 2f, hh - sw / 2f);
        c.drawRoundRect(r, hh * 0.22f, hh * 0.22f, line);

        fill.setColor(0xFFB0B0B0);
        r.set(bw, hh * 0.3f, bw + hh * 0.11f, hh * 0.7f);
        c.drawRoundRect(r, hh * 0.05f, hh * 0.05f, fill);

        int color = charging ? 0xFF4CD964 : (pct <= 15 ? 0xFFFF4D4D : 0xFFE6E6E6);
        fill.setColor(color);
        float pad = sw + hh * 0.06f;
        float left = pad;
        float right = bw - pad;
        float w = Math.max(hh * 0.06f, (right - left) * pct / 100f);
        r.set(left, pad, left + w, hh - pad);
        c.drawRoundRect(r, hh * 0.1f, hh * 0.1f, fill);

        if (charging) {
            float cx = bw / 2f;
            bp.reset();
            bp.moveTo(cx + 0.08f * hh, 0.14f * hh);
            bp.lineTo(cx - 0.28f * hh, 0.56f * hh);
            bp.lineTo(cx - 0.04f * hh, 0.56f * hh);
            bp.lineTo(cx - 0.12f * hh, 0.86f * hh);
            bp.lineTo(cx + 0.30f * hh, 0.42f * hh);
            bp.lineTo(cx + 0.06f * hh, 0.42f * hh);
            bp.close();
            c.drawPath(bp, bolt);
            c.drawPath(bp, boltEdge);
        }

        if (showPct) {
            Paint.FontMetrics fm = txt.getFontMetrics();
            float y = hh / 2f - (fm.ascent + fm.descent) / 2f;
            c.drawText(pct + "%", bw + hh * 0.11f + hh * 0.3f, y, txt);
        }
    }
}
