package com.kirnai.aod;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_PICK = 1;

    private SharedPreferences p;
    private TextView status;
    private TextView msgStatus;
    private TextView wxStatus;
    private Button shapeBtn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Prefs.get(this);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(44), dp(20), dp(24));
        sv.addView(root);
        setContentView(sv);

        root.addView(text("AOD Poco", 28, Color.WHITE));
        root.addView(text("Layar hitam dengan template pilihanmu, jam, tanggal, baterai, cuaca, dan pesan.", 14, 0xFF999999));

        root.addView(space(10));
        root.addView(button("Atur posisi (seret gambar, jam, dll)", v -> {
            Intent i = new Intent(this, AodActivity.class);
            i.putExtra("edit", true);
            startActivity(i);
        }));
        root.addView(button("Coba AOD sekarang", v -> startActivity(new Intent(this, AodActivity.class))));

        // ---- Template ----
        root.addView(section("Template"));
        root.addView(button("Pilih template (gambar / GIF / video)", v -> pickTemplate()));
        status = text("", 14, 0xFF7FD1FF);
        root.addView(status);
        root.addView(button("Hapus template", v -> {
            p.edit().remove(Prefs.TEMPLATE_URI).remove(Prefs.TEMPLATE_MIME).apply();
            refreshStatus();
        }));
        shapeBtn = button("", v -> pickShape());
        root.addView(shapeBtn);
        refreshShape();
        TextView tw = text("", 14, Color.WHITE);
        root.addView(tw);
        root.addView(seek(tw, "Ukuran template", Prefs.TEMPLATE_W, 10, 100, 40, "% lebar layar"));
        TextView an = text("", 14, Color.WHITE);
        root.addView(an);
        root.addView(seek(an, "Animasi GIF/video berjalan", Prefs.ANIM_SECONDS, 0, 60, 10, " detik (0 = terus)"));

        // ---- Tampilan ----
        root.addView(section("Tampilan"));
        root.addView(toggle("Jam dan tanggal", Prefs.SHOW_CLOCK, true));
        TextView cs = text("", 14, Color.WHITE);
        root.addView(cs);
        root.addView(seek(cs, "Ukuran jam", Prefs.CLOCK_SP, 16, 80, 30, " sp"));
        root.addView(toggle("Ikon baterai", Prefs.SHOW_BATTERY, true));
        root.addView(toggle("Angka persen di samping ikon baterai", Prefs.BATTERY_PCT, true));
        TextView dm = text("", 14, Color.WHITE);
        root.addView(dm);
        root.addView(seek(dm, "Redupkan tampilan", Prefs.DIM, 0, 90, 0, "%"));
        TextView br = text("", 14, Color.WHITE);
        root.addView(br);
        root.addView(seek(br, "Kecerahan layar", Prefs.BRIGHTNESS, 0, 40, 5, "%"));

        // ---- Cuaca ----
        root.addView(section("Informasi cuaca"));
        Switch wx = toggle("Tampilkan suhu, kondisi cuaca, dan kota", Prefs.WEATHER_ON, false);
        wx.setOnCheckedChangeListener((v, on) -> {
            p.edit().putBoolean(Prefs.WEATHER_ON, on).apply();
            if (on && !p.contains(Prefs.CITY_LAT)) {
                Toast.makeText(this, "Isi nama kota lalu tekan Simpan kota", Toast.LENGTH_LONG).show();
            }
        });
        root.addView(wx);
        final EditText city = new EditText(this);
        city.setTextColor(Color.WHITE);
        city.setHintTextColor(0xFF777777);
        city.setHint("Nama kota, mis. Bandung");
        city.setSingleLine(true);
        city.setText(p.getString(Prefs.CITY_NAME, ""));
        root.addView(city);
        wxStatus = text(p.contains(Prefs.CITY_LAT) ? "Kota tersimpan: " + p.getString(Prefs.CITY_NAME, "") : "Kota belum diatur",
                14, 0xFF7FD1FF);
        root.addView(button("Simpan kota & cek cuaca", v -> {
            String name = city.getText().toString().trim();
            if (name.isEmpty()) {
                Toast.makeText(this, "Isi nama kota dulu", Toast.LENGTH_SHORT).show();
                return;
            }
            wxStatus.setText("Mencari...");
            Weather.setCity(this, name, res -> wxStatus.setText(res));
        }));
        root.addView(wxStatus);
        root.addView(text("Butuh internet. Data cuaca dari Open-Meteo, diperbarui tiap 30 menit saat AOD tampil.", 12, 0xFF777777));

        // ---- Pesan ----
        root.addView(section("Pesan belum dibaca"));
        Switch msg = toggle("Tampilkan jumlah pesan (WhatsApp dan lainnya)", Prefs.MSG_ON, false);
        msg.setOnCheckedChangeListener((v, on) -> {
            p.edit().putBoolean(Prefs.MSG_ON, on).apply();
            if (on && !notifAccess()) {
                Toast.makeText(this, "Izinkan \"AOD Poco\" di Akses notifikasi", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            }
        });
        root.addView(msg);
        msgStatus = text("", 14, 0xFF7FD1FF);
        root.addView(msgStatus);
        root.addView(button("Buka pengaturan akses notifikasi",
                v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))));
        root.addView(text("Gelembung hijau = WhatsApp, gelembung biru = pesan lain (Telegram, SMS, dll). "
                + "Angka dihitung dari notifikasi yang masih ada di HP.", 12, 0xFF777777));

        // ---- Hemat baterai ----
        root.addView(section("Hemat baterai"));
        root.addView(toggle("Matikan AOD saat baterai rendah (kecuali sedang dicas)", Prefs.SAVER_ON, true));
        TextView sl = text("", 14, Color.WHITE);
        root.addView(sl);
        root.addView(seek(sl, "AOD mati di bawah", Prefs.SAVER_LEVEL, 5, 50, 15, "%"));

        // ---- Otomatis ----
        root.addView(section("Aktif otomatis"));
        root.addView(toggle("Hanya saat sedang dicas", Prefs.CHARGING_ONLY, false));
        TextView tm = text("", 14, Color.WHITE);
        root.addView(tm);
        root.addView(timerSeek(tm));
        Switch auto = toggle("Aktif otomatis saat layar mati", Prefs.AUTO, false);
        auto.setOnCheckedChangeListener((v, on) -> {
            p.edit().putBoolean(Prefs.AUTO, on).apply();
            if (on) askPermissions();
            applyService();
        });
        root.addView(auto);

        root.addView(space(14));
        root.addView(text("Ketuk 2x di layar AOD untuk keluar. Ketuk 1x untuk memutar ulang animasi.", 13, 0xFF999999));
        root.addView(text("Di HyperOS, aktifkan juga: Autostart, dan Baterai > Tanpa batasan untuk aplikasi ini, "
                + "serta izin \"Tampilkan pop-up saat berjalan di latar belakang\".", 13, 0xFF999999));

        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyService();
        msgStatus.setText(notifAccess() ? "Akses notifikasi: aktif" : "Akses notifikasi: belum diizinkan");
    }

    private boolean notifAccess() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    private void askPermissions() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan \"Tampil di atas aplikasi lain\" lalu kembali ke sini", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
        }
    }

    private void applyService() {
        Intent i = new Intent(this, AodService.class);
        if (p.getBoolean(Prefs.AUTO, false) && Settings.canDrawOverlays(this)) {
            try {
                startForegroundService(i);
            } catch (Exception e) {
                Toast.makeText(this, "Gagal menjalankan layanan: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            stopService(i);
        }
    }

    private void pickTemplate() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        startActivityForResult(i, REQ_PICK);
    }

    private void pickShape() {
        new AlertDialog.Builder(this)
                .setTitle("Bentuk template")
                .setItems(ShapeFrame.LABELS, (d, i) -> {
                    p.edit().putString(Prefs.SHAPE, ShapeFrame.KEYS[i]).apply();
                    refreshShape();
                })
                .show();
    }

    private void refreshShape() {
        String cur = p.getString(Prefs.SHAPE, "asli");
        String label = ShapeFrame.LABELS[0];
        for (int i = 0; i < ShapeFrame.KEYS.length; i++) {
            if (ShapeFrame.KEYS[i].equals(cur)) label = ShapeFrame.LABELS[i];
        }
        shapeBtn.setText("Bentuk template: " + label);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        String mime = getContentResolver().getType(u);
        p.edit().putString(Prefs.TEMPLATE_URI, u.toString())
                .putString(Prefs.TEMPLATE_MIME, mime == null ? "" : mime).apply();
        TemplateCache.warm(this);
        refreshStatus();
    }

    private void refreshStatus() {
        String u = p.getString(Prefs.TEMPLATE_URI, null);
        String m = p.getString(Prefs.TEMPLATE_MIME, "");
        if (u == null) {
            status.setText("Template: belum dipilih");
        } else if (m != null && m.startsWith("video")) {
            status.setText("Template: video dipilih");
        } else if (m != null && m.contains("gif")) {
            status.setText("Template: GIF dipilih");
        } else {
            status.setText("Template: gambar dipilih");
        }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private TextView section(String s) {
        TextView t = text(s, 18, 0xFF7FD1FF);
        t.setPadding(0, dp(24), 0, dp(4));
        return t;
    }

    // 1-60 detik per 1 detik, lalu 65-600 detik per 5 detik
    private SeekBar timerSeek(TextView label) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(167);
        int cur = p.getInt(Prefs.TIMER_SEC, 300);
        sb.setProgress(cur <= 60 ? cur - 1 : 59 + (cur - 60) / 5);
        label.setText("AOD mati otomatis setelah: " + fmt(cur));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int pr, boolean fromUser) {
                int v = pr < 60 ? pr + 1 : 60 + (pr - 59) * 5;
                p.edit().putInt(Prefs.TIMER_SEC, v).apply();
                label.setText("AOD mati otomatis setelah: " + fmt(v));
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        return sb;
    }

    private static String fmt(int s) {
        if (s < 60) return s + " detik";
        int m = s / 60;
        int r = s % 60;
        return r == 0 ? m + " menit" : m + " menit " + r + " detik";
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private Switch toggle(String label, String key, boolean def) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setPadding(0, dp(8), 0, dp(8));
        s.setChecked(p.getBoolean(key, def));
        s.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean(key, on).apply());
        return s;
    }

    private SeekBar seek(TextView label, String name, String key, int min, int max, int def, String unit) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        int cur = p.getInt(key, def);
        sb.setProgress(cur - min);
        label.setText(name + ": " + cur + unit);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int v = progress + min;
                p.edit().putInt(key, v).apply();
                label.setText(name + ": " + v + unit);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        return sb;
    }
}
