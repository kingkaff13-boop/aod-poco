package com.kirnai.aod;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_PICK = 1;

    private SharedPreferences p;
    private TextView status;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Prefs.get(this);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.BLACK);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(44), dp(20), dp(24));
        sv.addView(root);
        setContentView(sv);

        root.addView(text("AOD Poco", 28, Color.WHITE));
        root.addView(text("Layar hitam dengan template pilihanmu, jam, tanggal, dan baterai.", 14, 0xFF999999));

        root.addView(space(18));
        root.addView(button("Pilih template (gambar / GIF / video)", v -> pickTemplate()));
        status = text("", 14, 0xFF7FD1FF);
        root.addView(status);
        root.addView(button("Hapus template", v -> {
            p.edit().remove(Prefs.TEMPLATE_URI).remove(Prefs.TEMPLATE_MIME).apply();
            refreshStatus();
        }));

        root.addView(space(18));
        root.addView(toggle("Tampilkan jam dan tanggal buatan", Prefs.SHOW_CLOCK, true));
        root.addView(toggle("Hanya saat sedang dicas", Prefs.CHARGING_ONLY, false));

        root.addView(space(10));
        TextView br = text("", 14, Color.WHITE);
        root.addView(br);
        root.addView(seek(br, "Kecerahan", Prefs.BRIGHTNESS, 1, 40, 5, "%"));

        TextView tp = text("", 14, Color.WHITE);
        root.addView(tp);
        root.addView(seek(tp, "Ukuran template", Prefs.TEMPLATE_PCT, 5, 50, 18, "% tinggi layar"));

        TextView cs = text("", 14, Color.WHITE);
        root.addView(cs);
        root.addView(seek(cs, "Ukuran jam", Prefs.CLOCK_SP, 16, 80, 30, " sp"));

        TextView an = text("", 14, Color.WHITE);
        root.addView(an);
        root.addView(seek(an, "Animasi GIF/video berjalan", Prefs.ANIM_SECONDS, 0, 60, 10, " detik (0 = terus)"));

        root.addView(space(18));
        root.addView(button("Coba AOD sekarang", v -> startActivity(new Intent(this, AodActivity.class))));

        root.addView(space(10));
        Switch auto = toggle("Aktif otomatis saat layar mati", Prefs.AUTO, false);
        auto.setOnCheckedChangeListener((v, on) -> {
            p.edit().putBoolean(Prefs.AUTO, on).apply();
            if (on) askPermissions();
            applyService();
        });
        root.addView(auto);

        root.addView(space(14));
        root.addView(text("Ketuk 2x di layar AOD untuk keluar. Ketuk 1x untuk memutar ulang animasi.", 13, 0xFF999999));
        root.addView(text("Di HyperOS, aktifkan juga: Autostart, dan Baterai > Tanpa batasan untuk aplikasi ini, "
                + "serta izin \"Tampilkan pop-up saat berjalan di latar belakang\".", 13, 0xFF999999));

        refreshStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyService();
    }

    private void askPermissions() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan \"Tampil di atas aplikasi lain\" lalu kembali ke sini", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
        }
    }

    private void applyService() {
        Intent i = new Intent(this, AodService.class);
        if (p.getBoolean(Prefs.AUTO, false) && Settings.canDrawOverlays(this)) {
            try {
                startForegroundService(i);
            } catch (Exception e) {
                Toast.makeText(this, "Gagal menjalankan layanan: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            stopService(i);
        }
    }

    private void pickTemplate() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        startActivityForResult(i, REQ_PICK);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        String mime = getContentResolver().getType(u);
        p.edit().putString(Prefs.TEMPLATE_URI, u.toString())
                .putString(Prefs.TEMPLATE_MIME, mime == null ? "" : mime).apply();
        refreshStatus();
    }

    private void refreshStatus() {
        String u = p.getString(Prefs.TEMPLATE_URI, null);
        String m = p.getString(Prefs.TEMPLATE_MIME, "");
        if (u == null) {
            status.setText("Template: belum dipilih");
        } else if (m != null && m.startsWith("video")) {
            status.setText("Template: video dipilih");
        } else if (m != null && m.contains("gif")) {
            status.setText("Template: GIF dipilih");
        } else {
            status.setText("Template: gambar dipilih");
        }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, float sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private View space(int h) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(h)));
        return v;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private Switch toggle(String label, String key, boolean def) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setPadding(0, dp(8), 0, dp(8));
        s.setChecked(p.getBoolean(key, def));
        s.setOnCheckedChangeListener((v, on) -> p.edit().putBoolean(key, on).apply());
        return s;
    }

    private SeekBar seek(TextView label, String name, String key, int min, int max, int def, String unit) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        int cur = p.getInt(key, def);
        sb.setProgress(cur - min);
        label.setText(name + ": " + cur + unit);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int v = progress + min;
                p.edit().putInt(key, v).apply();
                label.setText(name + ": " + v + unit);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        return sb;
    }
}
