package com.kirnai.aod;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Ikon cuaca buatan sendiri. type: 0 cerah, 1 cerah berawan, 2 berawan, 3 kabut, 4 hujan, 5 petir, 6 salju. */
public class WeatherIconView extends View {
    private final float s;
    private int type;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();

    public WeatherIconView(Context c, float sizePx) {
        super(c);
        s = sizePx;
    }

    void setType(int t) {
        type = t;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension((int) s, (int) s);
    }

    @Override
    protected void onDraw(Canvas c) {
        switch (type) {
            case 0:
                sun(c, 0.5f, 0.5f, 0.2f);
                break;
            case 1:
                sun(c, 0.36f, 0.36f, 0.16f);
                cloud(c, 0.22f, 0.34f, 0.72f, 0xFFCFD8DC);
                break;
            case 2:
                cloud(c, 0.04f, 0.2f, 0.92f, 0xFFB0BEC5);
                break;
            case 3:
                cloud(c, 0.1f, 0.06f, 0.78f, 0xFFB0BEC5);
                lines(c, 0xFFB0BEC5, new float[]{0.2f, 0.68f, 0.8f, 0.68f, 0.26f, 0.78f, 0.74f, 0.78f, 0.2f, 0.88f, 0.8f, 0.88f});
                break;
            case 4:
                cloud(c, 0.08f, 0.06f, 0.84f, 0xFF90A4AE);
                lines(c, 0xFF4FC3F7, new float[]{0.38f, 0.68f, 0.33f, 0.84f, 0.54f, 0.68f, 0.49f, 0.84f, 0.70f, 0.68f, 0.65f, 0.84f});
                break;
            case 5:
                cloud(c, 0.08f, 0.04f, 0.84f, 0xFF78909C);
                bolt(c);
                break;
            default:
                cloud(c, 0.08f, 0.06f, 0.84f, 0xFFCFD8DC);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFFFFFFF);
                c.drawCircle(0.36f * s, 0.78f * s, 0.04f * s, p);
                c.drawCircle(0.52f * s, 0.88f * s, 0.04f * s, p);
                c.drawCircle(0.68f * s, 0.78f * s, 0.04f * s, p);
                break;
        }
    }

    private void sun(Canvas c, float cx, float cy, float r) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFC857);
        c.drawCircle(cx * s, cy * s, r * s, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.045f * s);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i < 8; i++) {
            double a = Math.toRadians(45.0 * i);
            float c1 = (float) Math.cos(a);
            float s1 = (float) Math.sin(a);
            c.drawLine((cx + c1 * r * 1.4f) * s, (cy + s1 * r * 1.4f) * s,
                    (cx + c1 * r * 1.8f) * s, (cy + s1 * r * 1.8f) * s, p);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void cloud(Canvas c, float ox, float oy, float k, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.save();
        c.translate(ox * s, oy * s);
        c.scale(k * s, k * s);
        c.drawCircle(0.30f, 0.46f, 0.20f, p);
        c.drawCircle(0.54f, 0.34f, 0.27f, p);
        c.drawCircle(0.78f, 0.50f, 0.18f, p);
        rf.set(0.20f, 0.48f, 0.86f, 0.68f);
        c.drawRoundRect(rf, 0.10f, 0.10f, p);
        c.restore();
    }

    private void lines(Canvas c, int color, float[] pts) {
        p.setStyle(Paint.Style.STROKE);
        p.setColor(color);
        p.setStrokeWidth(0.05f * s);
        p.setStrokeCap(Paint.Cap.ROUND);
        for (int i = 0; i + 3 < pts.length; i += 4) {
            c.drawLine(pts[i] * s, pts[i + 1] * s, pts[i + 2] * s, pts[i + 3] * s, p);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void bolt(Canvas c) {
        path.reset();
        path.moveTo(0.56f * s, 0.58f * s);
        path.lineTo(0.42f * s, 0.80f * s);
        path.lineTo(0.52f * s, 0.80f * s);
        path.lineTo(0.46f * s, 0.98f * s);
        path.lineTo(0.66f * s, 0.74f * s);
        path.lineTo(0.55f * s, 0.74f * s);
        path.lineTo(0.62f * s, 0.58f * s);
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFD54F);
        c.drawPath(path, p);
    }
}
