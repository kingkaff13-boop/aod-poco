package com.kirnai.aod;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** Cuaca dari Open-Meteo (gratis, tanpa kunci API). Kota dicari lewat nama, tanpa izin lokasi. */
final class Weather {
    interface Done {
        void run(String msg);
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private Weather() {}

    private static String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream o = new ByteArrayOutputStream()) {
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return o.toString("UTF-8");
        } finally {
            c.disconnect();
        }
    }

    private static void fetch(SharedPreferences p) throws Exception {
        String url = "https://api.open-meteo.com/v1/forecast?latitude=" + p.getString(Prefs.CITY_LAT, "0")
                + "&longitude=" + p.getString(Prefs.CITY_LON, "0")
                + "&current=temperature_2m,weather_code&timezone=auto";
        JSONObject cur = new JSONObject(get(url)).getJSONObject("current");
        p.edit().putFloat(Prefs.W_TEMP, (float) cur.getDouble("temperature_2m"))
                .putInt(Prefs.W_CODE, cur.getInt("weather_code"))
                .putLong(Prefs.W_TIME, System.currentTimeMillis()).apply();
    }

    /** Perbarui cuaca di latar belakang bila data sudah lebih dari 30 menit (atau force). */
    static void refresh(Context c, boolean force, Runnable done) {
        final SharedPreferences p = Prefs.get(c.getApplicationContext());
        if (!p.contains(Prefs.CITY_LAT)) return;
        long age = System.currentTimeMillis() - p.getLong(Prefs.W_TIME, 0);
        if (!force && age < 30 * 60 * 1000L) return;
        new Thread(() -> {
            try {
                fetch(p);
                if (done != null) MAIN.post(done);
            } catch (Exception ignored) {
            }
        }).start();
    }

    /** Cari kota lewat nama, simpan koordinatnya, lalu ambil cuaca pertama. */
    static void setCity(Context c, String name, Done cb) {
        final SharedPreferences p = Prefs.get(c.getApplicationContext());
        new Thread(() -> {
            String msg;
            try {
                String body = get("https://geocoding-api.open-meteo.com/v1/search?count=1&language=id&name="
                        + URLEncoder.encode(name, "UTF-8"));
                JSONArray r = new JSONObject(body).optJSONArray("results");
                if (r == null || r.length() == 0) {
                    msg = "Kota tidak ditemukan, coba nama lain";
                } else {
                    JSONObject x = r.getJSONObject(0);
                    String nm = x.optString("name", name);
                    p.edit().putString(Prefs.CITY_NAME, nm)
                            .putString(Prefs.CITY_LAT, String.valueOf(x.getDouble("latitude")))
                            .putString(Prefs.CITY_LON, String.valueOf(x.getDouble("longitude")))
                            .apply();
                    fetch(p);
                    msg = "Tersimpan: " + nm + ", " + Math.round(p.getFloat(Prefs.W_TEMP, 0)) + "°C";
                }
            } catch (Exception e) {
                msg = "Gagal terhubung ke internet";
            }
            final String m = msg;
            MAIN.post(() -> cb.run(m));
        }).start();
    }

    static String desc(int c) {
        if (c == 0) return "Cerah";
        if (c == 1) return "Cerah berawan";
        if (c == 2) return "Berawan sebagian";
        if (c == 3) return "Berawan";
        if (c == 45 || c == 48) return "Berkabut";
        if (c >= 51 && c <= 57) return "Gerimis";
        if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return "Hujan";
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) return "Salju";
        if (c >= 95) return "Badai petir";
        return "Berawan";
    }

    static int iconType(int c) {
        if (c == 0) return 0;
        if (c <= 2) return 1;
        if (c == 3) return 2;
        if (c == 45 || c == 48) return 3;
        if ((c >= 51 && c <= 67) || (c >= 80 && c <= 82)) return 4;
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) return 6;
        if (c >= 95) return 5;
        return 2;
    }
}
