package com.kirnai.aod;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

public class AodService extends Service {
    private static final String CHANNEL = "aod";

    // true setelah timer AOD habis: layar mati berikutnya tidak memunculkan AOD lagi
    static volatile boolean skipNext;

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_ON.equals(i.getAction())) {
                skipNext = false;
                return;
            }
            if (!Intent.ACTION_SCREEN_OFF.equals(i.getAction())) return;

            // Tombol power ditekan saat AOD tampil: tutup AOD, biarkan layar mati.
            AodActivity cur = AodActivity.instance;
            if (cur != null) {
                cur.finish();
                return;
            }

            if (skipNext) {
                skipNext = false;
                return;
            }

            if (Prefs.get(c).getBoolean(Prefs.CHARGING_ONLY, false) && !charging(c)) return;

            // Hemat baterai: jangan munculkan AOD kalau baterai rendah dan tidak dicas.
            if (Prefs.get(c).getBoolean(Prefs.SAVER_ON, true) && !charging(c)
                    && level(c) <= Prefs.get(c).getInt(Prefs.SAVER_LEVEL, 15)) return;

            // Jaga CPU tetap bangun sebentar supaya AOD tidak tertunda saat HP mau tidur.
            try {
                PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
                pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aodpoco:launch").acquire(5000);
            } catch (Exception ignored) {
            }

            Intent a = new Intent(c, AodActivity.class);
            a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP
                    | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            a.putExtra("auto", true);
            try {
                c.startActivity(a);
            } catch (Exception ignored) {
            }
        }
    };

    static int level(Context c) {
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b == null) return 100;
        int l = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int s = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        return s > 0 && l >= 0 ? l * 100 / s : 100;
    }

    static boolean charging(Context c) {
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        return b != null && b.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "AOD", NotificationManager.IMPORTANCE_MIN));
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("AOD aktif")
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1, n);
        }
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(screenOff, f);
        TemplateCache.warm(this);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        try {
            unregisterReceiver(screenOff);
        } catch (Exception ignored) {
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
