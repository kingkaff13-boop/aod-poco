package com.kirnai.aod;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Emoji gelembung chat buatan sendiri, dengan lencana jumlah pesan belum dibaca. */
public class BubbleIconView extends View {
    private final float s;
    private final int tint;
    private int count;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tail = new Path();
    private final RectF rf = new RectF();

    public BubbleIconView(Context c, float sizePx, int tint) {
        super(c);
        s = sizePx;
        this.tint = tint;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeWidth(0.045f * s);
        stroke.setColor(0xFF1B1B1B);
        txt.setColor(0xFFFFFFFF);
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setFakeBoldText(true);
    }

    void setCount(int n) {
        count = n;
        invalidate();
    }

    @Override
    protected void onMeasure(int w, int h) {
        setMeasuredDimension((int) s, (int) s);
    }

    @Override
    protected void onDraw(Canvas c) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(tint);
        rf.set(0.06f * s, 0.14f * s, 0.84f * s, 0.72f * s);
        c.drawRoundRect(rf, 0.22f * s, 0.22f * s, fill);

        tail.reset();
        tail.moveTo(0.18f * s, 0.66f * s);
        tail.lineTo(0.16f * s, 0.92f * s);
        tail.lineTo(0.42f * s, 0.70f * s);
        tail.close();
        c.drawPath(tail, fill);

        fill.setColor(0xFF1B1B1B);
        c.drawCircle(0.33f * s, 0.40f * s, 0.045f * s, fill);
        c.drawCircle(0.57f * s, 0.40f * s, 0.045f * s, fill);
        rf.set(0.32f * s, 0.36f * s, 0.58f * s, 0.58f * s);
        c.drawArc(rf, 20, 140, false, stroke);

        if (count > 0) {
            fill.setColor(0xFFFF3B30);
            c.drawCircle(0.80f * s, 0.22f * s, 0.2f * s, fill);
            String t = count > 99 ? "99+" : String.valueOf(count);
            txt.setTextSize((t.length() <= 2 ? 0.24f : 0.16f) * s);
            Paint.FontMetrics fm = txt.getFontMetrics();
            c.drawText(t, 0.80f * s, 0.22f * s - (fm.ascent + fm.descent) / 2f, txt);
        }
    }
}
