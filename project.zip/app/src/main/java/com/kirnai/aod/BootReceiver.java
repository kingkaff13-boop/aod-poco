package com.kirnai.aod;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) return;
        if (!Prefs.get(c).getBoolean(Prefs.AUTO, false) || !Settings.canDrawOverlays(c)) return;
        try {
            c.startForegroundService(new Intent(c, AodService.class));
        } catch (Exception ignored) {
        }
    }
}
