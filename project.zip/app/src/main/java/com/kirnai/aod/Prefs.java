package com.kirnai.aod;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String TEMPLATE_URI = "template_uri";
    static final String TEMPLATE_MIME = "template_mime";
    static final String AUTO = "auto";
    static final String CHARGING_ONLY = "charging_only";
    static final String SHOW_CLOCK = "show_clock";
    static final String ANIM_SECONDS = "anim_seconds";
    static final String BRIGHTNESS = "brightness";
    static final String TEMPLATE_PCT = "template_pct";
    static final String CLOCK_SP = "clock_sp";

    private Prefs() {}

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences("aod", Context.MODE_PRIVATE);
    }
}
