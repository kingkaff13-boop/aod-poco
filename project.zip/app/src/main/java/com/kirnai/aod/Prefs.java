package com.kirnai.aod;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String TEMPLATE_URI = "template_uri";
    static final String TEMPLATE_MIME = "template_mime";
    static final String AUTO = "auto";
    static final String CHARGING_ONLY = "charging_only";
    static final String SHOW_CLOCK = "show_clock";
    static final String ANIM_SECONDS = "anim_seconds";
    static final String BRIGHTNESS = "brightness";
    static final String CLOCK_SP = "clock_sp";
    static final String TIMER_SEC = "timer_sec";
    static final String TEMPLATE_W = "template_w";
    static final String SHAPE = "shape";
    static final String DIM = "dim";
    static final String SHOW_BATTERY = "show_battery";
    static final String BATTERY_PCT = "battery_pct";
    static final String SAVER_ON = "saver_on";
    static final String SAVER_LEVEL = "saver_level";
    static final String WEATHER_ON = "weather_on";
    static final String CITY_NAME = "city_name";
    static final String CITY_LAT = "city_lat";
    static final String CITY_LON = "city_lon";
    static final String W_TEMP = "w_temp";
    static final String W_CODE = "w_code";
    static final String W_TIME = "w_time";
    static final String MSG_ON = "msg_on";

    static final String[] IDS = {"tpl", "clock", "bat", "wx", "msg"};

    private Prefs() {}

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences("aod", Context.MODE_PRIVATE);
    }

    static float posX(Context c, String id, float def) {
        return get(c).getFloat("pos_" + id + "_x", def);
    }

    static float posY(Context c, String id, float def) {
        return get(c).getFloat("pos_" + id + "_y", def);
    }

    static void savePos(Context c, String id, float x, float y) {
        get(c).edit().putFloat("pos_" + id + "_x", x).putFloat("pos_" + id + "_y", y).apply();
    }

    static void resetPos(Context c) {
        SharedPreferences.Editor e = get(c).edit();
        for (String id : IDS) {
            e.remove("pos_" + id + "_x").remove("pos_" + id + "_y");
        }
        e.apply();
    }
}
