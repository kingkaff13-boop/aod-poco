package com.kirnai.aod;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class AodActivity extends Activity {
    static AodActivity instance;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private SharedPreferences p;
    private boolean edit, fromService, dead, showPct, saverOn, cropVideo, hasVideo;
    private int saverLevel, vw, vh;
    private FrameLayout layer;
    private BatteryView battery;
    private LinearLayout wxBox, msgBox;
    private WeatherIconView wxIcon;
    private TextView wxTemp, wxDesc;
    private BubbleIconView bubWa, bubOther;
    private AnimatedImageDrawable anim;
    private MediaPlayer mp;
    private GestureDetector gd;
    private ImageView tplImg;

    private final Runnable stopAnim = () -> {
        if (anim != null) anim.stop();
        if (mp != null) {
            try {
                mp.pause();
            } catch (Exception ignored) {
            }
        }
    };

    private final Runnable autoOff = () -> {
        // Lepas "layar tetap menyala" supaya layar mati normal, dan jangan munculkan AOD lagi satu kali.
        AodService.skipNext = true;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        finish();
    };

    private final Runnable shift = new Runnable() {
        @Override
        public void run() {
            if (layer != null) {
                float m = dp(18);
                layer.setTranslationX((rnd.nextFloat() * 2 - 1) * m);
                layer.setTranslationY((rnd.nextFloat() * 2 - 1) * m);
            }
            h.postDelayed(this, 60000);
        }
    };

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int pct = scale > 0 ? level * 100 / scale : level;
            boolean charging = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
            if (battery != null) battery.set(pct, charging, showPct);
            if (!edit && fromService && !charging) {
                if (p.getBoolean(Prefs.CHARGING_ONLY, false)) finish();
                if (saverOn && pct <= saverLevel) finish();
            }
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        instance = this;
        overridePendingTransition(0, 0);
        p = Prefs.get(this);
        edit = getIntent().getBooleanExtra("edit", false);
        fromService = getIntent().getBooleanExtra("auto", false);
        saverOn = p.getBoolean(Prefs.SAVER_ON, true);
        saverLevel = p.getInt(Prefs.SAVER_LEVEL, 15);
        showPct = p.getBoolean(Prefs.BATTERY_PCT, true);
        final int clockSp = p.getInt(Prefs.CLOCK_SP, 30);

        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = edit ? 0.5f : Math.max(0.003f, p.getInt(Prefs.BRIGHTNESS, 5) / 100f);
        getWindow().setAttributes(lp);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        layer = new FrameLayout(this);
        layer.setAlpha(edit ? 1f : Math.max(0.05f, 1f - p.getInt(Prefs.DIM, 0) / 100f));
        root.addView(layer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Template (gambar / GIF / video) dengan bentuk pilihan
        String us = p.getString(Prefs.TEMPLATE_URI, null);
        if (us != null || edit) {
            int side = (int) (getResources().getDisplayMetrics().widthPixels * p.getInt(Prefs.TEMPLATE_W, 40) / 100f);
            String shape = p.getString(Prefs.SHAPE, "asli");
            ShapeFrame tpl = new ShapeFrame(this);
            tpl.setShape(shape);
            if (us != null) {
                loadTemplate(tpl, Uri.parse(us), p.getString(Prefs.TEMPLATE_MIME, ""), !"asli".equals(shape));
            } else {
                TextView t = new TextView(this);
                t.setText("Template");
                t.setTextColor(0xFF888888);
                t.setGravity(Gravity.CENTER);
                tpl.addView(t, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }
            place(tpl, "tpl", side, side, 0.5f, 0.18f);
        }

        // Jam dan tanggal
        if (p.getBoolean(Prefs.SHOW_CLOCK, true)) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);

            TextClock clock = new TextClock(this);
            clock.setFormat12Hour("h:mm");
            clock.setFormat24Hour("HH:mm");
            clock.setTextSize(clockSp);
            clock.setTextColor(0xFFDDDDDD);
            clock.setGravity(Gravity.CENTER);
            col.addView(clock);

            TextClock date = new TextClock(this);
            date.setFormat12Hour("EEEE, d MMMM");
            date.setFormat24Hour("EEEE, d MMMM");
            date.setTextSize(Math.max(10, clockSp * 0.4f));
            date.setTextColor(0xFFAAAAAA);
            date.setGravity(Gravity.CENTER);
            col.addView(date);

            place(col, "clock", ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0.5f, 0.50f);
        }

        // Baterai (ikon gambar)
        if (p.getBoolean(Prefs.SHOW_BATTERY, true)) {
            battery = new BatteryView(this, spf(clockSp * 0.5f));
            place(battery, "bat", ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0.5f, 0.60f);
        }

        // Cuaca
        if (p.getBoolean(Prefs.WEATHER_ON, false)) {
            wxBox = new LinearLayout(this);
            wxBox.setOrientation(LinearLayout.HORIZONTAL);
            wxBox.setGravity(Gravity.CENTER_VERTICAL);
            wxIcon = new WeatherIconView(this, spf(clockSp * 1.1f));
            wxBox.addView(wxIcon);
            LinearLayout t = new LinearLayout(this);
            t.setOrientation(LinearLayout.VERTICAL);
            t.setPadding(dp(8), 0, 0, 0);
            wxTemp = new TextView(this);
            wxTemp.setTextSize(Math.max(12, clockSp * 0.6f));
            wxTemp.setTextColor(0xFFDDDDDD);
            wxDesc = new TextView(this);
            wxDesc.setTextSize(Math.max(10, clockSp * 0.34f));
            wxDesc.setTextColor(0xFFAAAAAA);
            t.addView(wxTemp);
            t.addView(wxDesc);
            wxBox.addView(t);
            place(wxBox, "wx", ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0.5f, 0.68f);
            updateWeather();
            Weather.refresh(this, false, () -> {
                if (!dead) updateWeather();
            });
        }

        // Pesan belum dibaca (emoji gelembung buatan sendiri)
        if (p.getBoolean(Prefs.MSG_ON, false)) {
            msgBox = new LinearLayout(this);
            msgBox.setOrientation(LinearLayout.HORIZONTAL);
            msgBox.setGravity(Gravity.CENTER_VERTICAL);
            int s = (int) spf(clockSp * 1.3f);
            bubWa = new BubbleIconView(this, s, 0xFF43C96B);
            bubOther = new BubbleIconView(this, s, 0xFF5BA8F5);
            LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            gap.setMargins(dp(6), 0, dp(6), 0);
            msgBox.addView(bubWa, gap);
            msgBox.addView(bubOther, gap);
            place(msgBox, "msg", ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0.5f, 0.78f);
            NotifListener.onChange = this::updateMsgs;
            updateMsgs();
        }

        if (edit) addEditControls(root);

        setContentView(root);
        hideBars();

        gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                finish();
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                restartAnim();
                return true;
            }
        });

        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (!edit) {
            h.postDelayed(shift, 60000);
            h.postDelayed(autoOff, p.getInt(Prefs.TIMER_SEC, 300) * 1000L);
            scheduleStop();
        }
    }

    // ---------- Penempatan dan seret ----------

    private void place(View v, String id, int w, int hgt, float dx, float dy) {
        layer.addView(v, new FrameLayout.LayoutParams(w, hgt, Gravity.TOP | Gravity.LEFT));
        v.addOnLayoutChangeListener((view, l, t, r, b, oldL, oldT, oldR, oldB) -> {
            if (r - l != oldR - oldL || b - t != oldB - oldT) applyPos(view, id, dx, dy);
        });
        if (edit) {
            GradientDrawable g = new GradientDrawable();
            g.setColor(0x22FFFFFF);
            g.setStroke(dp(1), 0xFF3A8DFF);
            v.setBackground(g);
            drag(v, id);
        }
    }

    private void applyPos(View v, String id, float dx, float dy) {
        int fw = Math.max(0, layer.getWidth() - v.getWidth());
        int fh = Math.max(0, layer.getHeight() - v.getHeight());
        v.setX(Prefs.posX(this, id, dx) * fw);
        v.setY(Prefs.posY(this, id, dy) * fh);
    }

    private void drag(View v, String id) {
        final float[] o = new float[2];
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    o[0] = view.getX() - e.getRawX();
                    o[1] = view.getY() - e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    view.setX(Math.max(0, Math.min(layer.getWidth() - view.getWidth(), e.getRawX() + o[0])));
                    view.setY(Math.max(0, Math.min(layer.getHeight() - view.getHeight(), e.getRawY() + o[1])));
                    return true;
                case MotionEvent.ACTION_UP:
                    int fw = layer.getWidth() - view.getWidth();
                    int fh = layer.getHeight() - view.getHeight();
                    Prefs.savePos(this, id, fw > 0 ? view.getX() / fw : 0.5f, fh > 0 ? view.getY() / fh : 0.5f);
                    return true;
                default:
                    return false;
            }
        });
    }

    private void addEditControls(FrameLayout root) {
        TextView hint = new TextView(this);
        hint.setText("Seret gambar, jam, baterai, cuaca, dan pesan ke posisi yang kamu mau");
        hint.setTextColor(0xFF7FD1FF);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP);
        hl.setMargins(dp(20), dp(40), dp(20), 0);
        root.addView(hint, hl);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        Button reset = new Button(this);
        reset.setText("Reset posisi");
        reset.setAllCaps(false);
        reset.setOnClickListener(v -> {
            Prefs.resetPos(this);
            recreate();
        });
        Button done = new Button(this);
        done.setText("Selesai");
        done.setAllCaps(false);
        done.setOnClickListener(v -> finish());
        bar.addView(reset);
        bar.addView(done);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        bl.bottomMargin = dp(40);
        root.addView(bar, bl);
    }

    // ---------- Data tampilan ----------

    private void updateWeather() {
        if (wxBox == null) return;
        if (!p.contains(Prefs.W_TIME)) {
            if (edit) {
                wxIcon.setType(0);
                wxTemp.setText("29°");
                wxDesc.setText("Cerah · Kota");
                wxBox.setVisibility(View.VISIBLE);
            } else {
                wxBox.setVisibility(View.GONE);
            }
            return;
        }
        int code = p.getInt(Prefs.W_CODE, 0);
        wxIcon.setType(Weather.iconType(code));
        wxTemp.setText(Math.round(p.getFloat(Prefs.W_TEMP, 0)) + "°");
        String city = p.getString(Prefs.CITY_NAME, "");
        wxDesc.setText(Weather.desc(code) + (city.isEmpty() ? "" : " · " + city));
        wxBox.setVisibility(View.VISIBLE);
    }

    private void updateMsgs() {
        if (msgBox == null) return;
        int wa = edit ? 3 : NotifListener.wa;
        int ot = edit ? 12 : NotifListener.other;
        bubWa.setCount(wa);
        bubOther.setCount(ot);
        bubWa.setVisibility(wa > 0 ? View.VISIBLE : View.GONE);
        bubOther.setVisibility(ot > 0 ? View.VISIBLE : View.GONE);
        msgBox.setVisibility(wa + ot > 0 ? View.VISIBLE : View.GONE);
    }

    // ---------- Template: gambar / GIF / video ----------

    private void loadTemplate(ShapeFrame tpl, Uri u, String mime, boolean crop) {
        FrameLayout.LayoutParams fill = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER);
        if (mime != null && mime.startsWith("video")) {
            hasVideo = true;
            cropVideo = crop;
            final TextureView tv = new TextureView(this);
            tpl.addView(tv, fill);
            tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
                @Override
                public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int hgt) {
                    startVideo(tv, st, u);
                }

                @Override
                public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int hgt) {
                    fitVideo(tv);
                }

                @Override
                public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                    releaseVideo();
                    return true;
                }

                @Override
                public void onSurfaceTextureUpdated(SurfaceTexture st) {
                }
            });
        } else {
            ImageView img = new ImageView(this);
            tplImg = img;
            img.setScaleType(crop ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
            tpl.addView(img, fill);
            try {
                Drawable d = TemplateCache.get(this, u);
                img.setImageDrawable(d);
                if (d instanceof AnimatedImageDrawable) {
                    anim = (AnimatedImageDrawable) d;
                    anim.setRepeatCount(AnimatedImageDrawable.REPEAT_INFINITE);
                    anim.start();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Template tidak bisa dibuka, pilih ulang", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void startVideo(TextureView tv, SurfaceTexture st, Uri u) {
        try {
            mp = new MediaPlayer();
            mp.setDataSource(this, u);
            mp.setSurface(new Surface(st));
            mp.setLooping(true);
            mp.setVolume(0f, 0f);
            mp.setOnVideoSizeChangedListener((m, w, hgt) -> {
                vw = w;
                vh = hgt;
                fitVideo(tv);
            });
            mp.setOnErrorListener((m, what, extra) -> true);
            mp.setOnPreparedListener(MediaPlayer::start);
            mp.prepareAsync();
        } catch (Exception e) {
            Toast.makeText(this, "Video tidak bisa dibuka, pilih ulang", Toast.LENGTH_LONG).show();
        }
    }

    private void fitVideo(TextureView tv) {
        if (vw <= 0 || vh <= 0 || tv.getWidth() <= 0 || tv.getHeight() <= 0) return;
        float vwf = tv.getWidth();
        float vhf = tv.getHeight();
        float a = (float) vw / vh;
        float b = vwf / vhf;
        float sx;
        float sy;
        if (cropVideo) {
            if (a > b) {
                sx = a / b;
                sy = 1f;
            } else {
                sx = 1f;
                sy = b / a;
            }
        } else {
            if (a > b) {
                sx = 1f;
                sy = b / a;
            } else {
                sx = a / b;
                sy = 1f;
            }
        }
        Matrix m = new Matrix();
        m.setScale(sx, sy, vwf / 2f, vhf / 2f);
        tv.setTransform(m);
    }

    private void releaseVideo() {
        if (mp != null) {
            try {
                mp.release();
            } catch (Exception ignored) {
            }
            mp = null;
        }
    }

    private void scheduleStop() {
        h.removeCallbacks(stopAnim);
        int s = p.getInt(Prefs.ANIM_SECONDS, 10);
        if (s > 0 && (anim != null || hasVideo)) h.postDelayed(stopAnim, s * 1000L);
    }

    private void restartAnim() {
        if (anim != null) anim.start();
        if (mp != null) {
            try {
                mp.seekTo(0);
                mp.start();
            } catch (Exception ignored) {
            }
        }
        if (!edit) scheduleStop();
    }

    private void hideBars() {
        if (android.os.Build.VERSION.SDK_INT < 30) return;
        getWindow().setDecorFitsSystemWindows(false);
        WindowInsetsController c = getWindow().getInsetsController();
        if (c != null) {
            c.hide(WindowInsets.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (!edit && gd != null) gd.onTouchEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dead = true;
        if (instance == this) instance = null;
        if (msgBox != null) NotifListener.onChange = null;
        if (anim != null) anim.stop();
        if (tplImg != null) tplImg.setImageDrawable(null);
        h.removeCallbacksAndMessages(null);
        releaseVideo();
        try {
            unregisterReceiver(batteryReceiver);
        } catch (Exception ignored) {
        }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private float spf(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, getResources().getDisplayMetrics());
    }
}
