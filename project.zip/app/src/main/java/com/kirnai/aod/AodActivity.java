package com.kirnai.aod;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.Random;

public class AodActivity extends Activity {
    static AodActivity instance;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private SharedPreferences p;
    private View content;
    private TextView battery;
    private AnimatedImageDrawable anim;
    private VideoView video;
    private boolean fromService;
    private GestureDetector gd;

    private final Runnable stopAnim = () -> {
        if (anim != null) anim.stop();
        if (video != null) video.pause();
    };

    private final Runnable autoOff = () -> {
        // Lepas "layar tetap menyala" supaya layar mati normal, dan jangan munculkan AOD lagi satu kali.
        AodService.skipNext = true;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        finish();
    };

    private final Runnable shift = new Runnable() {
        @Override
        public void run() {
            if (content != null) {
                float m = dp(18);
                content.setTranslationX((rnd.nextFloat() * 2 - 1) * m);
                content.setTranslationY((rnd.nextFloat() * 2 - 1) * m);
            }
            h.postDelayed(this, 60000);
        }
    };

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int pct = scale > 0 ? level * 100 / scale : level;
            boolean charging = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0;
            battery.setText("Baterai " + pct + "%" + (charging ? " · mengisi" : ""));
            if (fromService && !charging && p.getBoolean(Prefs.CHARGING_ONLY, false)) finish();
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        instance = this;
        p = Prefs.get(this);
        final int clockSp = p.getInt(Prefs.CLOCK_SP, 30);
        fromService = getIntent().getBooleanExtra("auto", false);

        setShowWhenLocked(true);
        setTurnScreenOn(true);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = Math.max(0.01f, p.getInt(Prefs.BRIGHTNESS, 5) / 100f);
        getWindow().setAttributes(lp);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        content = col;
        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        String us = p.getString(Prefs.TEMPLATE_URI, null);
        if (us != null) {
            int hgt = (int) (getResources().getDisplayMetrics().heightPixels
                    * p.getInt(Prefs.TEMPLATE_PCT, 18) / 100f);
            FrameLayout tpl = new FrameLayout(this);
            col.addView(tpl, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, hgt));
            loadTemplate(tpl, Uri.parse(us), p.getString(Prefs.TEMPLATE_MIME, ""));
        }

        if (p.getBoolean(Prefs.SHOW_CLOCK, true)) {
            TextClock clock = new TextClock(this);
            clock.setFormat12Hour("h:mm");
            clock.setFormat24Hour("HH:mm");
            clock.setTextSize(clockSp);
            clock.setTextColor(0xFFDDDDDD);
            clock.setGravity(Gravity.CENTER);
            col.addView(clock);

            TextClock date = new TextClock(this);
            date.setFormat12Hour("EEEE, d MMMM");
            date.setFormat24Hour("EEEE, d MMMM");
            date.setTextSize(Math.max(10, clockSp * 0.4f));
            date.setTextColor(0xFFAAAAAA);
            date.setGravity(Gravity.CENTER);
            col.addView(date);
        }

        battery = new TextView(this);
        battery.setTextSize(Math.max(10, clockSp * 0.38f));
        battery.setTextColor(0xFF999999);
        battery.setGravity(Gravity.CENTER);
        battery.setPadding(0, dp(8), 0, 0);
        col.addView(battery);

        setContentView(root);
        hideBars();

        gd = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onDoubleTap(MotionEvent e) {
                finish();
                return true;
            }

            @Override
            public boolean onSingleTapConfirmed(MotionEvent e) {
                restartAnim();
                return true;
            }
        });

        registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        h.postDelayed(shift, 60000);
        h.postDelayed(autoOff, p.getInt(Prefs.TIMER_SEC, 300) * 1000L);
        scheduleStop();
    }

    private void loadTemplate(FrameLayout tpl, Uri u, String mime) {
        FrameLayout.LayoutParams fill = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER);
        if (mime != null && mime.startsWith("video")) {
            video = new VideoView(this);
            tpl.addView(video, fill);
            video.setOnPreparedListener(mp -> {
                mp.setLooping(true);
                mp.setVolume(0f, 0f);
            });
            video.setOnErrorListener((mp, what, extra) -> true);
            video.setVideoURI(u);
            video.start();
        } else {
            ImageView img = new ImageView(this);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            tpl.addView(img, fill);
            try {
                Drawable d = ImageDecoder.decodeDrawable(
                        ImageDecoder.createSource(getContentResolver(), u),
                        (decoder, info, src) -> {
                            int big = Math.max(info.getSize().getWidth(), info.getSize().getHeight());
                            decoder.setTargetSampleSize(Math.max(1, big / 1600));
                        });
                img.setImageDrawable(d);
                if (d instanceof AnimatedImageDrawable) {
                    anim = (AnimatedImageDrawable) d;
                    anim.setRepeatCount(AnimatedImageDrawable.REPEAT_INFINITE);
                    anim.start();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Template tidak bisa dibuka, pilih ulang", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void scheduleStop() {
        h.removeCallbacks(stopAnim);
        int s = p.getInt(Prefs.ANIM_SECONDS, 10);
        if (s > 0 && (anim != null || video != null)) h.postDelayed(stopAnim, s * 1000L);
    }

    private void restartAnim() {
        if (anim != null) anim.start();
        if (video != null) {
            video.seekTo(0);
            video.start();
        }
        scheduleStop();
    }

    private void hideBars() {
        if (android.os.Build.VERSION.SDK_INT < 30) return;
        getWindow().setDecorFitsSystemWindows(false);
        WindowInsetsController c = getWindow().getInsetsController();
        if (c != null) {
            c.hide(WindowInsets.Type.systemBars());
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        gd.onTouchEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (instance == this) instance = null;
        h.removeCallbacksAndMessages(null);
        try {
            unregisterReceiver(batteryReceiver);
        } catch (Exception ignored) {
        }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
